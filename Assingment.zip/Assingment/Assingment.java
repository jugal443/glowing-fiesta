public class Assingment{
		  
	    public static void main(String[] args) {  
	        try  
	        {  
	        	int y =20/0; // Throw exception
	        
	        /*	try 
	        	{
	        		int X []= {1,3,5,7};
	        		{
	        			System.out.println(X[8]);
	        		}
	        	}
	        	   catch(ArrayIndexOutOfBoundsException e)  
	        	   {  
	        		   System.out.println(e);  
	        	   } 
	         */ 
	        }
	           
	        catch(ArithmeticException ae)  
	        {  
	            System.out.println(ae);  
	        }  

	        catch(Exception e)  
	        {  
	            System.out.println(e);  
	        }  
	        System.out.println("Hello");  
	    }
}
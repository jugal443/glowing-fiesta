class InvalidAgeException extends Exception
	{  
		 InvalidAgeException(String su)
		 {  
		  super(su);  
		 }  
	} 
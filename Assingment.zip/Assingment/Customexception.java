import java.util.Scanner;

public class Customexception 
{
	 void agevalidation(int age)throws InvalidAgeException
	{  
	     if(age<21)
	     {
	      throw new InvalidAgeException("Under age not eligible for vote please wait");  
	     }
	     else 
	     {
	      System.out.println("Please vote");  
	     }
	 }  
	     
	   public static void main(String args[])
	   {  
		   Customexception c = new Customexception();
		   Scanner sc = new Scanner(System.in);
		   int age = sc.nextInt();
		   
	      try
	      {   
	    	  c.agevalidation(age);  
	      }
	      catch(Exception e)
	      {
	    	  System.out.println("Exception occured: "+e);
	      }  
	  
	      System.out.println("Custom exception created");  
	  }  
}

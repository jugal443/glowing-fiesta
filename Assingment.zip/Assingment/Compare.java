import java.util.Scanner;

public class Compare{
			  
		   
		    public static void stringCompare(String str1, String str2) 
		    { 
		    	int res=0;
		        int x = str1.length(); 
		        int y = str2.length(); 
		        int lenmin = Math.min(x,y); 
		  
		        for (int i = 0; i < lenmin; i++)
		        { 
		            int str1ch = (int)str1.charAt(i); 
		            int str2ch = (int)str2.charAt(i); 
		            
		            int count;
					if(str1ch==str2ch || str1ch-32==str2ch || str1ch==str2ch-32 )
		            {
		            	count=0;
		            }
		            else if( str1ch>str2ch|| str1ch+32>str2ch)
		            {
		            	count =1;
		            }
		            else
		            {
		            	count =-1;
		            }
		        }
 
		     }
		  
		    
		    public static void main(String args[]) 
		    { 
		      Scanner sc = new Scanner(System.in);
		      System.out.println("Enter the First :");
		      String str1 = sc.nextLine();
		      System.out.println("Enter the second :");
		      String str2 = sc.nextLine();
		      stringCompare(str1,str2);
		      System.out.println(str1+""+str2+"");
		     
		      
		    } 
		}
public class Immutableclass1
{
	 public static void main(String args[])
	 { 
		 Methodimmutable  me = new Methodimmutable (311, "jugalsheoran443@gmail.com",21 , "Jugal Sheoran");
	      
	      System.out.println("Email: " + me.getEmail());
	      System.out.println(" Name " + me.getName());
	      System.out.println(" ID: " + me.getId());
	      System.out.println(" Age: " + me.getAge());
	      
	      //It shows the immutable class as there is no change in values once they are defined  
	      
	      @SuppressWarnings("unused")
	      Methodimmutable  me1 = new Methodimmutable (5777, "Adarsh@gmail.com",18 , "adarsh");
	      
	      System.out.println("Email: " + me.getEmail());
	      System.out.println(" Name " + me.getName());
	      System.out.println(" ID: " + me.getId());
	      System.out.println(" Age: " + me.getAge());
	      
	  }
}


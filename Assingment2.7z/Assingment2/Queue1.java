public class Queue1 {

	
	int que []=new int[5];
	int rr;
	int ff;
	int sz;
	public void insert(int value)
	{
		que[rr]=value;
		rr=rr+1;
		sz=sz+1;
	}
	public int remove()
	{
	 
		int value = que[ff];
		ff=ff+1;
		sz=sz-1;
		return value;
		
	}
	
	public void showall()
	{
		for(int no : que)
		{
			System.out.println(no);
		}
	}
}
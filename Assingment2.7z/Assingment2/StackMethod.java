
public class StackMethod
{
	public static void main(String args[])
	{
		Stack1 s = new Stack1();
		s.push(2);
		s.push(4);
		s.push(6);
		s.push(7);
		s.push(5);
		
		
		System.out.println("Elements of stack are :");
		s.showall();
		
		
		
		System.out.println("Elements of stack After are :");
		s.pop();
		s.pop();
		s.pop();
		s.showall();
	}
}

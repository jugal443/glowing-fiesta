
public class QueueMethod
{
	public static void main (String args [])
	{
		Queue1 q = new Queue1();
		q.insert(3);
		q.insert(5);
		q.insert(6);
		q.insert(8);
		q.insert(9);
		
		System.out.println("Elements in que :");
		q.showall();
		
		System.out.println("Elements after removal in que :");
		q.remove();
		q.remove();
		q.showall();
	
	}
}
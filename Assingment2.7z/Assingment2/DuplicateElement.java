import java.util.*;
public class DuplicateElement
{


	public static void main(String args[]) 
	{  
        List<String> Li = new ArrayList<String>();  
        Li.add("Jugal");  
        Li.add("Arun");  
        Li.add("Nidhi");  
        Li.add("Aniket");
        Li.add("Aniket");
        Li.add("Adarsh");
        Li.add("Himanshu");
        Li.add("Jugal");
		
        for(String l4 :Li)
        	{ 
        		System.out.println(l4.toString()); // Here .to string() returns the value in the same Sequence
        	}
        
        
        Set<String> S1 = new HashSet<String>(Li);  // Hash set only contains unique elements 
        System.out.println("List After Duplicate Removal:"+S1);  
	}
}
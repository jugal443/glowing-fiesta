
public class QueueMethod
{
	
		public static void main(String args[])
		  {
			MyQueue mm=new MyQueue(10);
			mm.enqueue(100);
			mm.enqueue(200);
			mm.enqueue(300);
			mm.enqueue(400);
			mm.enqueue(500);
			mm.enqueue(600);
			
			mm.showall();
			
			System.out.println("elements of queue after removal:");
			mm.dequeue();
			mm.dequeue();
			mm.showall();
			System.out.println(mm.isEmpty());
			
		  }
	
	
}
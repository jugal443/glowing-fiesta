
public class Stack1 
{
	
	int stc []=new int[5];
	int tp=0;
	public void push(int value)
	{
		stc[tp]=value;
		tp++;
	}
	public int pop()
	{
		tp--;
		int value = stc[tp];
		stc[tp]=0;
		return value;
	}
	
	public void showall()
	{
		for(int no : stc)
		{
			System.out.println(no);
		}
	}
}

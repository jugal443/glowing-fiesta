import java.util.*;
public class MyQueue
{
  private int array[];
  private int capacity;
  private int size;
  private int front;
  private int rear;
		  public MyQueue(int size)
		  {
			  array=new int[size];
			  capacity=size;
			  front=0;
			  rear=-1;
		  }
		  public boolean isFull()
		  {
			  return front==capacity;
		  }
		  public boolean isEmpty()
		  {
			  return front==0;
		  }
		  
		  
		  
		  public void enqueue(int element)
		  {
			  if(isFull())
			  {
				  System.out.println("Queue is full");
				  System.exit(0);
			  }
			  else 
			  {
			  rear=rear+1;
			  array[rear]=element;
			  front=front+1;
			  }
		  }
		  
		  
		  public void dequeue()
		  {
			  if(isEmpty())
		     {
				  System.out.println("Queue is empty");
				  System.exit(0);
		     }
			 array [rear]=0;
			 rear=rear-1;
		  }
		 
		  
		  public void showall()
			{
				for(int no : array)
				{
					System.out.println(no);
				}
			}
  
}
